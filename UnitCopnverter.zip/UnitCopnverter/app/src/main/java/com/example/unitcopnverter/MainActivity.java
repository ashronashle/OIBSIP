package com.example.unitcopnverter;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private EditText valueInput;
    private Spinner inputUnitSpinner, outputUnitSpinner;
    private Button convertButton;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        valueInput = findViewById(R.id.valueInput);
        inputUnitSpinner = findViewById(R.id.inputUnitSpinner);
        outputUnitSpinner = findViewById(R.id.outputUnitSpinner);
        convertButton = findViewById(R.id.convertButton);
        textView = findViewById(R.id.textView);



        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.unit_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(R.layout.spinner_item);
        inputUnitSpinner.setAdapter(adapter);
        outputUnitSpinner.setAdapter(adapter);


        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertUnits();
            }
        });
    }

    private void convertUnits() {

        String inputValueString = valueInput.getText().toString();
        if (inputValueString.isEmpty()) {
            Toast.makeText(this, "Please enter a value", Toast.LENGTH_SHORT).show();
            return;
        }

        double inputValue = Double.parseDouble(inputValueString);


        String inputUnit = inputUnitSpinner.getSelectedItem().toString();
        String outputUnit = outputUnitSpinner.getSelectedItem().toString();


        double result = performConversion(inputValue, inputUnit, outputUnit);


        textView.setText( inputValue + " " + inputUnit + " = " + result + " " + outputUnit);

    }

    private double performConversion(double value, String inputUnit, String outputUnit) {

        double cmToM = 0.01;
        double gToKg = 0.001;


        if (inputUnit.equals("Centimeters") && outputUnit.equals("Meters")) {
            return value * cmToM;

        }
        else if (inputUnit.equals("Grams") && outputUnit.equals("Kilograms")) {
            return value * gToKg;
        }
        else if (inputUnit.equals("Meters") && outputUnit.equals("Centimeters")) {
            return value / cmToM;
        }
        else if (inputUnit.equals("Kilograms") && outputUnit.equals("Grams")) {
            return value / gToKg;
        }



        return value;
    }
}