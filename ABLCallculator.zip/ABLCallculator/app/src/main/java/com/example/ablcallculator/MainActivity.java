package com.example.ablcallculator;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity   {
TextView textView,answer;
double firstNum;
String operator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        answer = findViewById(R.id.textView);
        textView = findViewById(R.id.answer);


        Button button0= findViewById(R.id.button0);
        Button button1= findViewById(R.id.button1);
        Button button2= findViewById(R.id.button2);
        Button button3= findViewById(R.id.button3);
        Button button4= findViewById(R.id.button4);
        Button button5= findViewById(R.id.button5);
        Button button6= findViewById(R.id.button6);
        Button button7= findViewById(R.id.button7);
        Button button8= findViewById(R.id.button8);
        Button button9= findViewById(R.id.button9);
        Button buttonSub= findViewById(R.id.buttonSubtract);
        Button buttonAdd= findViewById(R.id.buttonAddition);
        Button buttonMul= findViewById(R.id.buttonMultiplication);
        Button buttonDiv= findViewById(R.id.buttonDivision);
        Button buttonCancel= findViewById(R.id.buttonCancel);
        Button buttonAC= findViewById(R.id.buttonAC);
        Button buttonEquals= findViewById(R.id.buttonEquals);
        Button buttonComma= findViewById(R.id.buttonComma);


        ArrayList<Button>nums=new ArrayList<>();
        nums.add(button0);
        nums.add(button1);
        nums.add(button2);
        nums.add(button3);
        nums.add(button4);
        nums.add(button5);
        nums.add(button6);
        nums.add(button7);
        nums.add(button8);
        nums.add(button9);

        for (Button b:nums){
            b.setOnClickListener(view -> {

                String currentText = textView.getText().toString();
                if (!currentText.equals("0")) {
                    textView.setText(currentText + b.getText().toString());
                    answer.append(b.getText().toString());
                } else {
                    textView.setText(b.getText().toString());
                    answer.setText(b.getText().toString());
                }
            });
        }
       ArrayList <Button>signs = new ArrayList<>();
        signs.add(buttonSub);
        signs.add(buttonAdd);
        signs.add(buttonMul);
        signs.add(buttonDiv);


        for (Button b : signs) {
            b.setOnClickListener(view -> {
                firstNum = Double.parseDouble(textView.getText().toString());
                operator = b.getText().toString();
                textView.setText("");
                answer.append(" " + operator + " ");
            });
        }

        buttonAC.setOnClickListener(view -> {
            String num=answer.getText().toString();
            if(num.length()>1){
                answer.setText(num.substring(0,num.length()-1));
            }
           else if(num.length()==1&&!num.equals("")) {
              answer.setText("");
            }
            textView.setText("");
        });

        buttonCancel.setOnClickListener(view -> {

            textView.setText("");
            answer.setText("");
        });

        buttonComma.setOnClickListener(view -> {
            if (!textView.getText().toString().contains(",")){
               textView.setText(textView.getText().toString()+",");
    }
});

        buttonEquals.setOnClickListener(view -> {
            String expression = answer.getText().toString();
            String[] parts = expression.split(" ");

            // Check if the user has entered both numbers and an operator
            if (parts.length != 3) {
                // Display a popup message indicating that the calculation is incomplete
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Please enter both numbers and an operator before calculating.")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Close the dialog
                                dialog.dismiss();
                            }
                        });
                // Create and show the AlertDialog
                builder.create().show();
                return; // Exit the method to prevent further execution
            }

            try {
                double secondNum = Double.parseDouble(textView.getText().toString());
                double result;

                switch (operator) {
                    case "÷":
                        result = firstNum / secondNum;
                        break;
                    case "x":
                        result = firstNum * secondNum;
                        break;
                    case "-":
                        result = firstNum - secondNum;
                        break;
                    case "+":
                        result = firstNum + secondNum;
                        break;
                    default:
                        result = firstNum + secondNum;
                }

                String formattedResult = String.format("%.2f", result);
                textView.setText(formattedResult);
                firstNum = result;

            } catch (NumberFormatException e) {
                // Handle the case where the textView doesn't contain a valid number
                // For example, you can display an error message or log the error
                Log.e("Error", "Invalid number format: " + e.getMessage());
            }
        });

    }
}





