package com.example.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private ImageButton startButton, pauseButton, resetButton;
    private Handler handler;
    private boolean isRunning;
    private long milliseconds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        startButton = findViewById(R.id.play);
        pauseButton = findViewById(R.id.pause);
        resetButton = findViewById(R.id.stop);

        handler = new Handler();
        isRunning = false;

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isRunning) {
                    startTimer();
                    startButton.setVisibility(View.GONE);
                    pauseButton.setVisibility(View.VISIBLE);
                    resetButton.setEnabled(false);
                }
            }
        });

        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseTimer();
                startButton.setVisibility(View.VISIBLE);
                pauseButton.setVisibility(View.GONE);
                resetButton.setEnabled(true);
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
                startButton.setVisibility(View.VISIBLE);
                pauseButton.setVisibility(View.GONE);
                resetButton.setEnabled(false);
            }
        });
    }

    private void startTimer() {
        isRunning = true;
        handler.post(new Runnable() {
            @Override
            public void run() {
                milliseconds += 100;
                int seconds = (int) (milliseconds / 1000) % 60;
                int minutes = (int) ((milliseconds / (1000 * 60)) % 60);
                int millisecondsToShow = (int) (milliseconds % 1000) / 10; // Convert milliseconds to centiseconds
                String time = String.format("%02d:%02d:%02d", minutes, seconds, millisecondsToShow);
                textView.setText(time);
                if (isRunning) {
                    handler.postDelayed(this, 100);
                }
            }
        });
    }


    private void pauseTimer() {
        isRunning = false;
        handler.removeCallbacksAndMessages(null);
    }

    private void resetTimer() {
        if (isRunning) {
            pauseTimer();
        }
        isRunning = false;
        milliseconds = 0;
        textView.setText("00:00:00");
        handler.removeCallbacksAndMessages(null);
    }
}
